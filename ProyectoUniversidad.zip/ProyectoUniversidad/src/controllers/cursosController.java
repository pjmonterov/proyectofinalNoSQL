/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.google.gson.Gson;
import com.mongodb.Block;
import com.mongodb.DB;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import static com.mongodb.client.model.Filters.eq;
import configuration.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import models.*;
import org.bson.Document;

/**
 *
 * @author kpiedra
 */
public class cursosController {
    private MongoCollection<Document> cursos;
    private MongoCollection<cursos> cursoToInsert;
    Connection conn;
    Gson gson = new Gson();
    
    public void getCollection() {
       conn =  new Connection();
        cursos = conn.database.getCollection("cursos"); 
   cursoToInsert = conn.database.getCollection("cursos", cursos.class);
    }
    
    public void createCollection(String collectionName){
        conn.database.createCollection(collectionName);
    }
    
    public List<cursos> getAllCourses() {
        try{
        FindIterable<Document> findIterable = cursos.find(new Document());   
        Iterator it = findIterable.iterator();
        List<cursos> allCourses = new ArrayList<>();
        while (it.hasNext()) {
            Document d =(Document) it.next();
            d.remove("_id");
            System.out.println("doc: " + d.toJson());
            cursos curso = gson.fromJson(d.toJson(), cursos.class);
            System.out.println(curso.getNombreCurso());
            allCourses.add(curso);
        }
        return allCourses;
        }catch(Exception ignore){
            System.out.println(ignore.getMessage());
            conn.mongo.close();
            
        }finally{
            //conn.mongo.close();
        }
        return null;
    }
    
    public void insertCourse(cursos cursoAInsertar) {
        Boolean isRegistered;
        try{
            isRegistered = (cursos.find(eq("nombreCurso", cursoAInsertar.getNombreCurso())).first() != null ) ? true : false; 
        }catch(Exception e){
            
            isRegistered = false;
        }
        try{
        if(!isRegistered){
            cursoToInsert.insertOne(cursoAInsertar);
        }else{
            cursoToInsert.replaceOne(eq("nombreCurso", cursoAInsertar.getNombreCurso()), cursoAInsertar);
        }
        }catch(Exception ex){
            System.out.println("Could not insert data into database :" + ex.getMessage());
        }
    }
    
    public cursos getOneCourse(String courseName) {
        try{
       Document d = cursos.find(eq("nombreCurso", courseName)).first();
       System.out.println("doc: " + d.toJson());
       d.remove("_id");
       cursos curso = gson.fromJson(d.toJson(), cursos.class);
       System.out.println(curso.getNombreCurso());
       return curso;
        }catch(Exception e){
            System.out.println("Could not find any course");
        }
        return null;
    }
    
    public void removeCourse(String courseName) {
        try{    
        cursoToInsert.deleteOne(eq("nombreCurso", courseName));
        }catch(Exception e){
            System.out.println("Could not delete the course" );
        }
    }
}
    

