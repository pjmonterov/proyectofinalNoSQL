/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.util.List;

/**
 *
 * @author kpiedra
 */
public class cursos {
    private String nombreCurso;
    private String codigoCurso;
    private horarios horarios;

    public cursos() {
    }

    public cursos(String nombreCurso, String codigoCurso, horarios horarios) {
        this.nombreCurso = nombreCurso;
        this.codigoCurso = codigoCurso;
        this.horarios = horarios;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public String getCodigoCurso() {
        return codigoCurso;
    }

    public void setCodigoCurso(String codigoCurso) {
        this.codigoCurso = codigoCurso;
    }

    public horarios getHorarios() {
        return horarios;
    }

    public void setHorarios(horarios horarios) {
        this.horarios = horarios;
    }
    
    
    
    public class horarios{
        private String dia;
        private String hora;
        private laboratorios laboratorio;

        public horarios() {
        }
        
        public horarios(String dia, String hora, laboratorios laboratorio) {
            this.dia = dia;
            this.hora = hora;
            this.laboratorio = laboratorio;
        }

        public String getDia() {
            return dia;
        }

        public void setDia(String dia) {
            this.dia = dia;
        }

        public String getHora() {
            return hora;
        }

        public void setHora(String hora) {
            this.hora = hora;
        }

        public laboratorios getLaboratorio() {
            return laboratorio;
        }

        public void setLaboratorio(laboratorios laboratorio) {
            this.laboratorio = laboratorio;
        }
        
        public class laboratorios{
            private int id;
            private String nombreLab;
            private String edificio;

            public laboratorios(int id, String nombreLab, String edificio) {
                this.id = id;
                this.nombreLab = nombreLab;
                this.edificio = edificio;
            }

            public laboratorios() {
            }

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getNombreLab() {
                return nombreLab;
            }

            public void setNombreLab(String nombreLab) {
                this.nombreLab = nombreLab;
            }

            public String getEdificio() {
                return edificio;
            }

            public void setEdificio(String edificio) {
                this.edificio = edificio;
            }
            
            
        }
        
    }
    
}
