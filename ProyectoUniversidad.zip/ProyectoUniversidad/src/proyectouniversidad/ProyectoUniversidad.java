/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectouniversidad;

import controllers.*;
import models.*;
import java.util.List;

/**
 *
 * @author kpiedra
 */
public class ProyectoUniversidad {

    /**
     * @param args the command line arguments
     */

   /** public static void main(String[] args) {
        // TODO code application logic here
       cursosController cursosCtrll = new cursosController();
       //cursosCtrll.testCreateColl();
       
       cursosCtrll.getCollection();
       List<cursos> listaCursos = cursosCtrll.getAllCourses();
       cursos curso = listaCursos.get(0);
       System.out.println("Este es un curso: "+ curso.getNombreCurso());  
       
    /**   
       cursos nuevoCurso = new cursos();
       cursos.horarios nuevoHorario = nuevoCurso.new horarios();
       cursos.horarios.laboratorios lab = nuevoHorario.new laboratorios(2,"LAB223","C");
       cursos.horarios horarioAInsertar = nuevoCurso.new horarios("J", "M", lab);
       curso = new cursos("Progra 3","PROG003",horarioAInsertar);
       cursosCtrll.insertCourse(curso);
       
       cursos cursoBuscado = cursosCtrll.getOneCourse("Progra 2");
        System.out.println(cursoBuscado.getHorarios().getLaboratorio().getNombreLab());
       
        cursosCtrll.removeCourse("Progra 2");
      **/  
    //}

    
}
